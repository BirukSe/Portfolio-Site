"use client"

import { useEffect, useState, useRef } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { useInView } from "react-intersection-observer"
import {
  Github,
  Linkedin,
  Mail,
  Phone,
  MapPin,
  ExternalLink,
  Download,
  Menu,
  X,
  ChevronRight,
  Send,
  ArrowRight,
  Star,
  Award,
  Code,
  Briefcase,
  GraduationCap,
  User,
  Layers,
  MessageSquare,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ModeToggle } from "@/components/mode-toggle"
import { cn } from "@/lib/utils"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/hooks/use-toast"

export default function Home() {
  const [activeSection, setActiveSection] = useState("home")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const sectionsRef = useRef({})

  // Intersection observer for each section
  const useSectionObserver = (sectionId) => {
    const [ref, inView] = useInView({
      threshold: 0.3,
    })

    useEffect(() => {
      if (inView) {
        setActiveSection(sectionId)
      }
    }, [inView, sectionId])

    // Store the actual DOM element ID instead of the ref
    return ref
  }

  // Create refs for each section
  const homeRef = useSectionObserver("home")
  const aboutRef = useSectionObserver("about")
  const skillsRef = useSectionObserver("skills")
  const projectsRef = useSectionObserver("projects")
  const experienceRef = useSectionObserver("experience")
  const contactRef = useSectionObserver("contact")

  // Smooth scroll to section
  const scrollToSection = (sectionId) => {
    setMobileMenuOpen(false)
    // Use document.getElementById to find the element by its ID
    const section = document.getElementById(sectionId)
    if (section) {
      section.scrollIntoView({ behavior: "smooth" })
    }
  }

  // Handle contact form submission
  const handleContactSubmit = (e) => {
    e.preventDefault()
    toast({
      title: "Message sent!",
      description: "Thank you for your message. I'll get back to you soon.",
    })
    e.target.reset()
  }

  return (
    <div className="relative min-h-screen bg-gradient-to-b from-background to-background/80">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-[30%] -right-[10%] w-[50%] h-[70%] bg-gradient-to-b from-primary/20 to-transparent rounded-full blur-3xl opacity-30" />
        <div className="absolute top-[60%] -left-[10%] w-[40%] h-[60%] bg-gradient-to-t from-primary/20 to-transparent rounded-full blur-3xl opacity-20" />
      </div>

      {/* Side Navigation */}
      <nav className="fixed top-0 left-0 bottom-0 z-50 w-20 hidden lg:flex flex-col items-center justify-center gap-8 border-r border-border/50 bg-background/80 backdrop-blur-sm">
        <div className="absolute top-6">
          <ModeToggle />
        </div>

        <div className="flex flex-col items-center gap-8">
          <button
            onClick={() => scrollToSection("home")}
            className={cn(
              "relative w-12 h-12 rounded-xl flex items-center justify-center transition-all group",
              activeSection === "home" ? "bg-primary text-primary-foreground" : "hover:bg-primary/10",
            )}
          >
            <span
              className={cn(
                "absolute left-full ml-2 px-2 py-1 rounded-md text-sm font-medium whitespace-nowrap opacity-0 translate-x-2 transition-all",
                "group-hover:opacity-100 group-hover:translate-x-0",
                "bg-primary/10",
              )}
            >
              Home
            </span>
            <User className="w-5 h-5" />
          </button>

          <button
            onClick={() => scrollToSection("about")}
            className={cn(
              "relative w-12 h-12 rounded-xl flex items-center justify-center transition-all group",
              activeSection === "about" ? "bg-primary text-primary-foreground" : "hover:bg-primary/10",
            )}
          >
            <span
              className={cn(
                "absolute left-full ml-2 px-2 py-1 rounded-md text-sm font-medium whitespace-nowrap opacity-0 translate-x-2 transition-all",
                "group-hover:opacity-100 group-hover:translate-x-0",
                "bg-primary/10",
              )}
            >
              About
            </span>
            <User className="w-5 h-5" />
          </button>

          <button
            onClick={() => scrollToSection("skills")}
            className={cn(
              "relative w-12 h-12 rounded-xl flex items-center justify-center transition-all group",
              activeSection === "skills" ? "bg-primary text-primary-foreground" : "hover:bg-primary/10",
            )}
          >
            <span
              className={cn(
                "absolute left-full ml-2 px-2 py-1 rounded-md text-sm font-medium whitespace-nowrap opacity-0 translate-x-2 transition-all",
                "group-hover:opacity-100 group-hover:translate-x-0",
                "bg-primary/10",
              )}
            >
              Skills
            </span>
            <Code className="w-5 h-5" />
          </button>

          <button
            onClick={() => scrollToSection("projects")}
            className={cn(
              "relative w-12 h-12 rounded-xl flex items-center justify-center transition-all group",
              activeSection === "projects" ? "bg-primary text-primary-foreground" : "hover:bg-primary/10",
            )}
          >
            <span
              className={cn(
                "absolute left-full ml-2 px-2 py-1 rounded-md text-sm font-medium whitespace-nowrap opacity-0 translate-x-2 transition-all",
                "group-hover:opacity-100 group-hover:translate-x-0",
                "bg-primary/10",
              )}
            >
              Projects
            </span>
            <Layers className="w-5 h-5" />
          </button>

          <button
            onClick={() => scrollToSection("experience")}
            className={cn(
              "relative w-12 h-12 rounded-xl flex items-center justify-center transition-all group",
              activeSection === "experience" ? "bg-primary text-primary-foreground" : "hover:bg-primary/10",
            )}
          >
            <span
              className={cn(
                "absolute left-full ml-2 px-2 py-1 rounded-md text-sm font-medium whitespace-nowrap opacity-0 translate-x-2 transition-all",
                "group-hover:opacity-100 group-hover:translate-x-0",
                "bg-primary/10",
              )}
            >
              Experience
            </span>
            <Briefcase className="w-5 h-5" />
          </button>

          <button
            onClick={() => scrollToSection("contact")}
            className={cn(
              "relative w-12 h-12 rounded-xl flex items-center justify-center transition-all group",
              activeSection === "contact" ? "bg-primary text-primary-foreground" : "hover:bg-primary/10",
            )}
          >
            <span
              className={cn(
                "absolute left-full ml-2 px-2 py-1 rounded-md text-sm font-medium whitespace-nowrap opacity-0 translate-x-2 transition-all",
                "group-hover:opacity-100 group-hover:translate-x-0",
                "bg-primary/10",
              )}
            >
              Contact
            </span>
            <MessageSquare className="w-5 h-5" />
          </button>
        </div>

        <div className="absolute bottom-6 flex flex-col gap-4">
          <a
            href="https://github.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-primary/10 transition-colors"
          >
            <Github className="w-5 h-5" />
          </a>
          <a
            href="https://linkedin.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-primary/10 transition-colors"
          >
            <Linkedin className="w-5 h-5" />
          </a>
        </div>
      </nav>

      {/* Mobile Header */}
      <header className="fixed top-0 left-0 right-0 z-50 h-16 flex items-center justify-between px-4 lg:pl-24 lg:pr-6 bg-background/80 backdrop-blur-sm border-b border-border/50">
        <div className="font-bold text-xl">Biruk Seyoum</div>
        <div className="flex items-center gap-2">
          <div className="block lg:hidden">
            <ModeToggle />
          </div>
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            className="fixed inset-0 z-40 bg-background pt-16 lg:hidden"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <nav className="flex flex-col p-6 gap-2">
              <Button
                variant={activeSection === "home" ? "default" : "ghost"}
                className="justify-start h-12 text-lg"
                onClick={() => scrollToSection("home")}
              >
                <User className="mr-2 h-5 w-5" />
                Home
              </Button>
              <Button
                variant={activeSection === "about" ? "default" : "ghost"}
                className="justify-start h-12 text-lg"
                onClick={() => scrollToSection("about")}
              >
                <User className="mr-2 h-5 w-5" />
                About
              </Button>
              <Button
                variant={activeSection === "skills" ? "default" : "ghost"}
                className="justify-start h-12 text-lg"
                onClick={() => scrollToSection("skills")}
              >
                <Code className="mr-2 h-5 w-5" />
                Skills
              </Button>
              <Button
                variant={activeSection === "projects" ? "default" : "ghost"}
                className="justify-start h-12 text-lg"
                onClick={() => scrollToSection("projects")}
              >
                <Layers className="mr-2 h-5 w-5" />
                Projects
              </Button>
              <Button
                variant={activeSection === "experience" ? "default" : "ghost"}
                className="justify-start h-12 text-lg"
                onClick={() => scrollToSection("experience")}
              >
                <Briefcase className="mr-2 h-5 w-5" />
                Experience
              </Button>
              <Button
                variant={activeSection === "contact" ? "default" : "ghost"}
                className="justify-start h-12 text-lg"
                onClick={() => scrollToSection("contact")}
              >
                <MessageSquare className="mr-2 h-5 w-5" />
                Contact
              </Button>

              <div className="mt-auto pt-6 flex gap-4">
                <Button variant="outline" size="icon" asChild>
                  <a href="https://github.com/" target="_blank" rel="noopener noreferrer">
                    <Github className="h-5 w-5" />
                  </a>
                </Button>
                <Button variant="outline" size="icon" asChild>
                  <a href="https://linkedin.com/" target="_blank" rel="noopener noreferrer">
                    <Linkedin className="h-5 w-5" />
                  </a>
                </Button>
                <Button variant="outline" size="icon" asChild>
                  <a href="mailto:bseyoum003@gmail.com">
                    <Mail className="h-5 w-5" />
                  </a>
                </Button>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="pt-16 lg:pl-20">
        {/* Hero Section */}
        <section
          ref={homeRef}
          id="home"
          className="min-h-[calc(100vh-4rem)] flex flex-col justify-center relative overflow-hidden"
        >
          <div className="container px-4 md:px-6 flex flex-col lg:flex-row items-center gap-12">
            <motion.div
              className="flex-1 space-y-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="inline-block">
                <Badge className="text-sm px-3 py-1 bg-primary/10 text-primary border-primary/20 mb-4">
                  Full-Stack Developer
                </Badge>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight leading-tight">
                Hi, I'm <span className="text-primary">Biruk Seyoum</span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-[600px]">
                Building modern web applications with passion and precision. Transforming ideas into exceptional digital
                experiences.
              </p>

              <div className="flex flex-wrap gap-4 pt-4">
                <Button size="lg" className="rounded-full px-6" onClick={() => scrollToSection("projects")}>
                  View My Work
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button variant="outline" size="lg" className="rounded-full px-6" asChild>
                  <a href="/resume.pdf" download>
                    <Download className="mr-2 h-4 w-4" />
                    Download Resume
                  </a>
                </Button>
              </div>

              <div className="flex items-center gap-4 pt-6">
                <div className="flex -space-x-2">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <Star className="h-5 w-5 text-primary" />
                  </div>
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <Award className="h-5 w-5 text-primary" />
                  </div>
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <Code className="h-5 w-5 text-primary" />
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  Google Developer Group Hackathon <span className="font-bold">Grand Prize Winner</span>
                </p>
              </div>
            </motion.div>

            <motion.div
              className="relative"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="relative w-72 h-72 md:w-96 md:h-96 rounded-full overflow-hidden border-4 border-primary/20">
                <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent rounded-full" />
                <Image
                  src="/placeholder.svg?height=400&width=400"
                  alt="Biruk Seyoum"
                  fill
                  className="object-cover"
                  priority
                />
              </div>

              <div className="absolute -bottom-4 -right-4 bg-background rounded-lg p-3 shadow-lg border border-border">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                  <span className="text-sm font-medium">Available for work</span>
                </div>
              </div>
            </motion.div>
          </div>

          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full h-10 w-10"
              onClick={() => scrollToSection("about")}
            >
              <ChevronRight className="h-6 w-6 -rotate-90" />
            </Button>
          </div>
        </section>

        {/* About Section */}
        <section ref={aboutRef} id="about" className="py-20 scroll-mt-16 bg-muted/30">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col gap-2 mb-12">
              <h2 className="text-3xl font-bold tracking-tight">About Me</h2>
              <div className="w-20 h-1.5 bg-primary rounded-full" />
            </div>

            <div className="grid lg:grid-cols-[1fr_1.2fr] gap-12">
              <motion.div
                className="relative rounded-2xl overflow-hidden aspect-square max-w-md mx-auto lg:mx-0"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <Image src="/placeholder.svg?height=600&width=600" alt="Biruk Seyoum" fill className="object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                  <div className="p-6 text-white">
                    <h3 className="text-xl font-bold">Biruk Seyoum</h3>
                    <p>Full-Stack Developer</p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                className="space-y-6"
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold">Who am I?</h3>
                  <p className="text-lg">
                    I'm a passionate full-stack developer based in Addis Ababa, Ethiopia, with experience in building
                    scalable web applications. I specialize in React, Next.js, Node.js, and various other modern web
                    technologies.
                  </p>
                  <p>
                    I've contributed to the development of five scalable full-stack web applications, leveraging React
                    for dynamic front-end development and Node.js with MongoDB for the backend. I enjoy collaborating
                    with cross-functional teams to implement user-friendly interfaces and optimize application
                    performance.
                  </p>
                  <p>
                    I'm currently a software engineering student at Addis Ababa University, where I continue to expand
                    my knowledge and skills in software development.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-lg font-semibold mb-2">Location</h4>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-primary" />
                      <span>Addis Ababa, Ethiopia</span>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-2">Email</h4>
                    <div className="flex items-center gap-2">
                      <Mail className="h-5 w-5 text-primary" />
                      <a href="mailto:bseyoum003@gmail.com" className="hover:underline">
                        bseyoum003@gmail.com
                      </a>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-2">Phone</h4>
                    <div className="flex items-center gap-2">
                      <Phone className="h-5 w-5 text-primary" />
                      <a href="tel:+251937454293" className="hover:underline">
                        +251 937454293
                      </a>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-2">Education</h4>
                    <div className="flex items-center gap-2">
                      <GraduationCap className="h-5 w-5 text-primary" />
                      <span>Software Engineering Student</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <Button className="rounded-full px-6" onClick={() => scrollToSection("contact")}>
                    Contact Me
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section ref={skillsRef} id="skills" className="py-20 scroll-mt-16">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col gap-2 mb-12">
              <h2 className="text-3xl font-bold tracking-tight">My Skills</h2>
              <div className="w-20 h-1.5 bg-primary rounded-full" />
            </div>

            <div className="grid gap-8">
              <motion.div
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <Card className="overflow-hidden border-none shadow-lg bg-gradient-to-br from-background to-muted">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-6">
                      <Layers className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-4">Frontend Development</h3>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">React / Next.js</span>
                          <span>95%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "95%" }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">HTML / CSS / Tailwind</span>
                          <span>90%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "90%" }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">JavaScript / TypeScript</span>
                          <span>85%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "85%" }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">React Native / Flutter</span>
                          <span>80%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "80%" }} />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="overflow-hidden border-none shadow-lg bg-gradient-to-br from-background to-muted">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-6">
                      <Code className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-4">Backend Development</h3>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">Node.js / Express</span>
                          <span>90%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "90%" }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">MongoDB / Databases</span>
                          <span>85%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "85%" }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">NestJS</span>
                          <span>80%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "80%" }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">Spring Boot</span>
                          <span>75%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "75%" }} />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="overflow-hidden border-none shadow-lg bg-gradient-to-br from-background to-muted">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-6">
                      <Briefcase className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-4">Tools & Others</h3>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">Git / GitHub</span>
                          <span>90%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "90%" }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">UI/UX Design</span>
                          <span>85%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "85%" }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">Responsive Design</span>
                          <span>95%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "95%" }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">AI Integration</span>
                          <span>80%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: "80%" }} />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                className="mt-12"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <h3 className="text-xl font-bold mb-6">Technologies I Work With</h3>
                <div className="flex flex-wrap gap-3">
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">React</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">Next.js</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">Node.js</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">Express</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">MongoDB</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">TypeScript</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">JavaScript</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">HTML5</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">CSS3</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">
                    Tailwind CSS
                  </Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">Flutter</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">
                    React Native
                  </Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">NestJS</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">
                    Spring Boot
                  </Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">Git</Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">
                    RESTful APIs
                  </Badge>
                  <Badge className="px-4 py-2 text-base bg-primary/10 text-primary border-primary/20">
                    Socket Programming
                  </Badge>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section ref={projectsRef} id="projects" className="py-20 scroll-mt-16 bg-muted/30">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col gap-2 mb-12">
              <h2 className="text-3xl font-bold tracking-tight">Featured Projects</h2>
              <div className="w-20 h-1.5 bg-primary rounded-full" />
            </div>

            <div className="grid gap-12">
              {/* Project 1 */}
              <motion.div
                className="group"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <div className="grid lg:grid-cols-2 gap-8 items-center">
                  <div className="relative overflow-hidden rounded-xl aspect-video">
                    <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Code Craft Preview"
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="space-y-6">
                    <Badge className="px-3 py-1 bg-primary/10 text-primary border-primary/20">Featured Project</Badge>
                    <h3 className="text-2xl font-bold">Code Craft</h3>
                    <p className="text-muted-foreground">AI-Powered Design-to-Code Generator</p>
                    <p>
                      Developed an intuitive AI-powered design-to-code generator that allows users to visually design
                      their UI by drawing directly on a canvas. With a single click on "Generate Code," the tool
                      automatically converts designs into fully functional code, enabling seamless front-end
                      development.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">Next.js</Badge>
                      <Badge variant="secondary">shadcn/ui</Badge>
                      <Badge variant="secondary">AI</Badge>
                      <Badge variant="secondary">Canvas API</Badge>
                    </div>
                    <div className="flex gap-4">
                      <Button className="rounded-full px-6" asChild>
                        <a href="https://code-craft-f8fu.vercel.app" target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="mr-2 h-4 w-4" />
                          Live Demo
                        </a>
                      </Button>
                      <Button variant="outline" className="rounded-full px-6" asChild>
                        <a href="https://github.com/" target="_blank" rel="noopener noreferrer">
                          <Github className="mr-2 h-4 w-4" />
                          Source Code
                        </a>
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Project 2 */}
              <motion.div
                className="group"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <div className="grid lg:grid-cols-2 gap-8 items-center lg:flex-row-reverse">
                  <div className="relative overflow-hidden rounded-xl aspect-video lg:order-2">
                    <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Vid-Chat Preview"
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="space-y-6 lg:order-1">
                    <Badge className="px-3 py-1 bg-primary/10 text-primary border-primary/20">Featured Project</Badge>
                    <h3 className="text-2xl font-bold">Vid-Chat</h3>
                    <p className="text-muted-foreground">Real-time Video Conferencing Platform</p>
                    <p>
                      Built a comprehensive video conferencing platform with real-time communication capabilities. The
                      platform supports video calls, screen sharing, and chat functionality, providing a seamless
                      communication experience for users.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">Next.js</Badge>
                      <Badge variant="secondary">shadcn/ui</Badge>
                      <Badge variant="secondary">Stream API</Badge>
                      <Badge variant="secondary">Socket Programming</Badge>
                    </div>
                    <div className="flex gap-4">
                      <Button className="rounded-full px-6" asChild>
                        <a
                          href="https://video-conferencing-platform-cenk-c3ghyvzj7.vercel.app/"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <ExternalLink className="mr-2 h-4 w-4" />
                          Live Demo
                        </a>
                      </Button>
                      <Button variant="outline" className="rounded-full px-6" asChild>
                        <a href="https://github.com/" target="_blank" rel="noopener noreferrer">
                          <Github className="mr-2 h-4 w-4" />
                          Source Code
                        </a>
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Project 3 */}
              <motion.div
                className="group"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <div className="grid lg:grid-cols-2 gap-8 items-center">
                  <div className="relative overflow-hidden rounded-xl aspect-video">
                    <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Kuriftu Resort Preview"
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="space-y-6">
                    <Badge className="px-3 py-1 bg-primary/10 text-primary border-primary/20">Featured Project</Badge>
                    <h3 className="text-2xl font-bold">Kuriftu Resort</h3>
                    <p className="text-muted-foreground">Modern Luxury Resort Website</p>
                    <p>
                      Designed and developed a modern website for Kuriftu Resort, showcasing the luxury accommodations,
                      amenities, and services. The website features a clean design, responsive layout, and intuitive
                      navigation to enhance the user experience.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">Next.js</Badge>
                      <Badge variant="secondary">Tailwind CSS</Badge>
                      <Badge variant="secondary">Responsive Design</Badge>
                    </div>
                    <div className="flex gap-4">
                      <Button className="rounded-full px-6" asChild>
                        <a href="https://kuriftu-inky.vercel.app/" target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="mr-2 h-4 w-4" />
                          Live Demo
                        </a>
                      </Button>
                      <Button variant="outline" className="rounded-full px-6" asChild>
                        <a href="https://github.com/" target="_blank" rel="noopener noreferrer">
                          <Github className="mr-2 h-4 w-4" />
                          Source Code
                        </a>
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* More Projects Button */}
              <div className="flex justify-center mt-8">
                <Button variant="outline" size="lg" className="rounded-full px-8">
                  View All Projects
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Experience Section */}
        <section ref={experienceRef} id="experience" className="py-20 scroll-mt-16">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col gap-2 mb-12">
              <h2 className="text-3xl font-bold tracking-tight">Experience & Education</h2>
              <div className="w-20 h-1.5 bg-primary rounded-full" />
            </div>

            <Tabs defaultValue="experience" className="w-full">
              <TabsList className="w-full max-w-md mx-auto grid grid-cols-2 mb-8">
                <TabsTrigger value="experience" className="text-base">
                  <Briefcase className="mr-2 h-4 w-4" />
                  Experience
                </TabsTrigger>
                <TabsTrigger value="education" className="text-base">
                  <GraduationCap className="mr-2 h-4 w-4" />
                  Education
                </TabsTrigger>
              </TabsList>

              <TabsContent value="experience" className="space-y-8 mt-6">
                <motion.div
                  className="relative pl-8 border-l-2 border-primary/30 ml-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="absolute -left-[17px] top-0 w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <div className="w-4 h-4 rounded-full bg-primary" />
                  </div>
                  <div className="mb-1 flex items-center">
                    <Badge className="mr-2">2022-2023</Badge>
                    <h3 className="text-xl font-bold">Pedro Tech Internship</h3>
                  </div>
                  <p className="text-muted-foreground mb-4">Full-Stack Developer Intern</p>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Contributed to the development of five scalable full-stack web applications.</li>
                    <li>Leveraged React for dynamic front-end development and Node.js with MongoDB for the backend.</li>
                    <li>Collaborated with cross-functional teams to implement user-friendly interfaces.</li>
                    <li>
                      Optimized application performance and ensured seamless integration between front and back-end
                      systems.
                    </li>
                  </ul>
                </motion.div>

                <motion.div
                  className="relative pl-8 border-l-2 border-primary/30 ml-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                >
                  <div className="absolute -left-[17px] top-0 w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <div className="w-4 h-4 rounded-full bg-primary" />
                  </div>
                  <div className="mb-1 flex items-center">
                    <Badge className="mr-2">2022</Badge>
                    <h3 className="text-xl font-bold">Evangadi Bootcamp</h3>
                  </div>
                  <p className="text-muted-foreground mb-4">Full-Stack Development Program</p>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Participated in a comprehensive full-stack development program.</li>
                    <li>Focused on building real-world applications using React, Node.js, and MongoDB.</li>
                    <li>Gained practical experience in developing responsive front-end interfaces.</li>
                    <li>Designed RESTful APIs and managed data with MongoDB.</li>
                    <li>
                      Exposure to Agile methodologies, version control with Git, and best practices for application
                      scalability.
                    </li>
                  </ul>
                </motion.div>

                <motion.div
                  className="relative pl-8 border-l-2 border-primary/30 ml-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="absolute -left-[17px] top-0 w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <div className="w-4 h-4 rounded-full bg-primary" />
                  </div>
                  <div className="mb-1 flex items-center">
                    <Badge className="mr-2">2023</Badge>
                    <h3 className="text-xl font-bold">Google Developer Group Hackathon</h3>
                  </div>
                  <p className="text-muted-foreground mb-4">Grand Prize Winner</p>
                  <p>
                    Won the grand prize at the Google Developer Group Hackathon for developing an innovative solution.
                    The project demonstrated exceptional technical skills and creativity, earning recognition from
                    industry experts.
                  </p>
                </motion.div>

                <motion.div
                  className="relative pl-8 border-l-2 border-primary/30 ml-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                >
                  <div className="absolute -left-[17px] top-0 w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <div className="w-4 h-4 rounded-full bg-primary" />
                  </div>
                  <div className="mb-1 flex items-center">
                    <Badge className="mr-2">2023</Badge>
                    <h3 className="text-xl font-bold">Hospitality Hackathon</h3>
                  </div>
                  <p className="text-muted-foreground mb-4">Participant</p>
                  <p>
                    Participated in the Hospitality Hackathon, developing solutions for the hospitality industry.
                    Collaborated with a team to create innovative applications addressing real-world challenges in the
                    hospitality sector.
                  </p>
                </motion.div>
              </TabsContent>

              <TabsContent value="education" className="space-y-8 mt-6">
                <motion.div
                  className="relative pl-8 border-l-2 border-primary/30 ml-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="absolute -left-[17px] top-0 w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <div className="w-4 h-4 rounded-full bg-primary" />
                  </div>
                  <div className="mb-1 flex items-center">
                    <Badge className="mr-2">2022-2027</Badge>
                    <h3 className="text-xl font-bold">Addis Ababa University</h3>
                  </div>
                  <p className="text-muted-foreground mb-4">Bachelor's Degree in Software Engineering</p>
                  <p>
                    Currently pursuing a Bachelor's Degree in Software Engineering at Addis Ababa University. Focusing
                    on advanced programming concepts, software architecture, and system design principles. Participating
                    in various university projects and tech communities to enhance practical skills.
                  </p>
                </motion.div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Contact Section */}
        <section ref={contactRef} id="contact" className="py-20 scroll-mt-16 bg-muted/30">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col gap-2 mb-12">
              <h2 className="text-3xl font-bold tracking-tight">Get In Touch</h2>
              <div className="w-20 h-1.5 bg-primary rounded-full" />
            </div>
            <div className="grid lg:grid-cols-2 gap-12">
              <motion.div
                className="space-y-6"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <h3 className="text-2xl font-bold">Let's Talk</h3>
                <p className="text-lg">
                  I'm always open to discussing new projects, creative ideas, or opportunities to be part of your
                  vision. Feel free to reach out to me using the contact form or through my social media profiles.
                </p>

                <div className="space-y-4 pt-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Mail className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Email</p>
                      <a href="mailto:bseyoum003@gmail.com" className="font-medium hover:underline">
                        bseyoum003@gmail.com
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Phone className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Phone</p>
                      <a href="tel:+251937454293" className="font-medium hover:underline">
                        +251 937454293
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <MapPin className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Location</p>
                      <p className="font-medium">Addis Ababa, Ethiopia</p>
                    </div>
                  </div>
                </div>

                <div className="pt-6">
                  <h4 className="font-semibold mb-4">Connect with me</h4>
                  <div className="flex gap-4">
                    <a
                      href="https://github.com/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
                    >
                      <Github className="h-5 w-5" />
                    </a>
                    <a
                      href="https://linkedin.com/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
                    >
                      <Linkedin className="h-5 w-5" />
                    </a>
                    <a
                      href="mailto:bseyoum003@gmail.com"
                      className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
                    >
                      <Mail className="h-5 w-5" />
                    </a>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <Card className="overflow-hidden border-none shadow-lg bg-gradient-to-br from-background to-muted">
                  <CardContent className="p-6">
                    <h3 className="text-2xl font-bold mb-6">Send Me a Message</h3>
                    <form className="space-y-6" onSubmit={handleContactSubmit}>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label htmlFor="first-name" className="text-sm font-medium">
                            First name
                          </label>
                          <input
                            id="first-name"
                            className="flex h-12 w-full rounded-lg border border-input bg-background px-4 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                            placeholder="John"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="last-name" className="text-sm font-medium">
                            Last name
                          </label>
                          <input
                            id="last-name"
                            className="flex h-12 w-full rounded-lg border border-input bg-background px-4 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                            placeholder="Doe"
                            required
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="email" className="text-sm font-medium">
                          Email
                        </label>
                        <input
                          id="email"
                          type="email"
                          className="flex h-12 w-full rounded-lg border border-input bg-background px-4 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="john.doe@example.com"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="subject" className="text-sm font-medium">
                          Subject
                        </label>
                        <input
                          id="subject"
                          className="flex h-12 w-full rounded-lg border border-input bg-background px-4 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="Project Inquiry"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="message" className="text-sm font-medium">
                          Message
                        </label>
                        <textarea
                          id="message"
                          className="flex min-h-[120px] w-full rounded-lg border border-input bg-background px-4 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="Tell me about your project..."
                          required
                        />
                      </div>
                      <Button type="submit" className="w-full h-12 rounded-full">
                        <Send className="mr-2 h-4 w-4" />
                        Send Message
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-10 border-t">
          <div className="container px-4 md:px-6">
            <div className="grid gap-8 lg:grid-cols-2">
              <div>
                <h3 className="text-2xl font-bold mb-4">Biruk Seyoum</h3>
                <p className="text-muted-foreground max-w-md">
                  Full-stack developer specializing in creating modern, responsive web applications with a focus on user
                  experience and performance.
                </p>
                <div className="flex gap-4 mt-6">
                  <a
                    href="https://github.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
                  >
                    <Github className="h-5 w-5" />
                  </a>
                  <a
                    href="https://linkedin.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
                  >
                    <Linkedin className="h-5 w-5" />
                  </a>
                  <a
                    href="mailto:bseyoum003@gmail.com"
                    className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
                  >
                    <Mail className="h-5 w-5" />
                  </a>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold mb-4">Quick Links</h4>
                  <ul className="space-y-2">
                    <li>
                      <button
                        onClick={() => scrollToSection("home")}
                        className="text-muted-foreground hover:text-foreground transition-colors"
                      >
                        Home
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => scrollToSection("about")}
                        className="text-muted-foreground hover:text-foreground transition-colors"
                      >
                        About
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => scrollToSection("skills")}
                        className="text-muted-foreground hover:text-foreground transition-colors"
                      >
                        Skills
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => scrollToSection("projects")}
                        className="text-muted-foreground hover:text-foreground transition-colors"
                      >
                        Projects
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => scrollToSection("experience")}
                        className="text-muted-foreground hover:text-foreground transition-colors"
                      >
                        Experience
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => scrollToSection("contact")}
                        className="text-muted-foreground hover:text-foreground transition-colors"
                      >
                        Contact
                      </button>
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-4">Contact Info</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <a
                        href="mailto:bseyoum003@gmail.com"
                        className="text-muted-foreground hover:text-foreground transition-colors"
                      >
                        bseyoum003@gmail.com
                      </a>
                    </li>
                    <li className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <a
                        href="tel:+251937454293"
                        className="text-muted-foreground hover:text-foreground transition-colors"
                      >
                        +251 937454293
                      </a>
                    </li>
                    <li className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">Addis Ababa, Ethiopia</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="border-t mt-10 pt-6 flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-sm text-muted-foreground text-center md:text-left">
                © {new Date().getFullYear()} Biruk Seyoum Abebe. All rights reserved.
              </p>
              <p className="text-sm text-muted-foreground">Designed & Built with ❤️</p>
            </div>
          </div>
        </footer>
      </main>
    </div>
  )
}
